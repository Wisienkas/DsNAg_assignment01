/**
 * @author nirei12 & thora12
 */
public interface PQ {
	public Element extractMin();
	public void Insert(Element e);
}
